<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugin/table/jquery-3.1.0.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugin/table/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugin/table/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugin/table/dataTables.bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugin/table/jquery.datetimepicker.full.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugin/table/autoNumeric.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
    	$('.angka').autoNumeric("init", {
        	aSign: 'Rp '
        });
    });
</script>