<?php return array (
  'sans-serif' => 
  array (
    'normal' => DOMPDF_FONT_DIR . 'Helvetica',
    'bold' => DOMPDF_FONT_DIR . 'Helvetica-Bold',
    'italic' => DOMPDF_FONT_DIR . 'Helvetica-Oblique',
    'bold_italic' => DOMPDF_FONT_DIR . 'Helvetica-BoldOblique',
  ),
  'times' => 
  array (
    'normal' => DOMPDF_FONT_DIR . 'Times-Roman',
    'bold' => DOMPDF_FONT_DIR . 'Times-Bold',
    'italic' => DOMPDF_FONT_DIR . 'Times-Italic',
    'bold_italic' => DOMPDF_FONT_DIR . 'Times-BoldItalic',
  ),
  'times-roman' => 
  array (
    'normal' => DOMPDF_FONT_DIR . 'Times-Roman',
    'bold' => DOMPDF_FONT_DIR . 'Times-Bold',
    'italic' => DOMPDF_FONT_DIR . 'Times-Italic',
    'bold_italic' => DOMPDF_FONT_DIR . 'Times-BoldItalic',
  ),
  'courier' => 
  array (
    'normal' => DOMPDF_FONT_DIR . 'Courier',
    'bold' => DOMPDF_FONT_DIR . 'Courier-Bold',
    'italic' => DOMPDF_FONT_DIR . 'Courier-Oblique',
    'bold_italic' => DOMPDF_FONT_DIR . 'Courier-BoldOblique',
  ),
  'helvetica' => 
  array (
    'normal' => DOMPDF_FONT_DIR . 'Helvetica',
    'bold' => DOMPDF_FONT_DIR . 'Helvetica-Bold',
    'italic' => DOMPDF_FONT_DIR . 'Helvetica-Oblique',
    'bold_italic' => DOMPDF_FONT_DIR . 'Helvetica-BoldOblique',
  ),
  'zapfdingbats' => 
  array (
    'normal' => DOMPDF_FONT_DIR . 'ZapfDingbats',
    'bold' => DOMPDF_FONT_DIR . 'ZapfDingbats',
    'italic' => DOMPDF_FONT_DIR . 'ZapfDingbats',
    'bold_italic' => DOMPDF_FONT_DIR . 'ZapfDingbats',
  ),
  'symbol' => 
  array (
    'normal' => DOMPDF_FONT_DIR . 'Symbol',
    'bold' => DOMPDF_FONT_DIR . 'Symbol',
    'italic' => DOMPDF_FONT_DIR . 'Symbol',
    'bold_italic' => DOMPDF_FONT_DIR . 'Symbol',
  ),
  'serif' => 
  array (
    'normal' => DOMPDF_FONT_DIR . 'Times-Roman',
    'bold' => DOMPDF_FONT_DIR . 'Times-Bold',
    'italic' => DOMPDF_FONT_DIR . 'Times-Italic',
    'bold_italic' => DOMPDF_FONT_DIR . 'Times-BoldItalic',
  ),
  'monospace' => 
  array (
    'normal' => DOMPDF_FONT_DIR . 'Courier',
    'bold' => DOMPDF_FONT_DIR . 'Courier-Bold',
    'italic' => DOMPDF_FONT_DIR . 'Courier-Oblique',
    'bold_italic' => DOMPDF_FONT_DIR . 'Courier-BoldOblique',
  ),
  'fixed' => 
  array (
    'normal' => DOMPDF_FONT_DIR . 'Courier',
    'bold' => DOMPDF_FONT_DIR . 'Courier-Bold',
    'italic' => DOMPDF_FONT_DIR . 'Courier-Oblique',
    'bold_italic' => DOMPDF_FONT_DIR . 'Courier-BoldOblique',
  ),
  'dejavu sans' => 
  array (
    'bold' => DOMPDF_FONT_DIR . 'DejaVuSans-Bold',
    'bold_italic' => DOMPDF_FONT_DIR . 'DejaVuSans-BoldOblique',
    'italic' => DOMPDF_FONT_DIR . 'DejaVuSans-Oblique',
    'normal' => DOMPDF_FONT_DIR . 'DejaVuSans',
  ),
  'dejavu sans light' => 
  array (
    'normal' => DOMPDF_FONT_DIR . 'DejaVuSans-ExtraLight',
  ),
  'dejavu sans condensed' => 
  array (
    'bold' => DOMPDF_FONT_DIR . 'DejaVuSansCondensed-Bold',
    'bold_italic' => DOMPDF_FONT_DIR . 'DejaVuSansCondensed-BoldOblique',
    'italic' => DOMPDF_FONT_DIR . 'DejaVuSansCondensed-Oblique',
    'normal' => DOMPDF_FONT_DIR . 'DejaVuSansCondensed',
  ),
  'dejavu sans mono' => 
  array (
    'bold' => DOMPDF_FONT_DIR . 'DejaVuSansMono-Bold',
    'bold_italic' => DOMPDF_FONT_DIR . 'DejaVuSansMono-BoldOblique',
    'italic' => DOMPDF_FONT_DIR . 'DejaVuSansMono-Oblique',
    'normal' => DOMPDF_FONT_DIR . 'DejaVuSansMono',
  ),
  'dejavu serif' => 
  array (
    'bold' => DOMPDF_FONT_DIR . 'DejaVuSerif-Bold',
    'bold_italic' => DOMPDF_FONT_DIR . 'DejaVuSerif-BoldItalic',
    'italic' => DOMPDF_FONT_DIR . 'DejaVuSerif-Italic',
    'normal' => DOMPDF_FONT_DIR . 'DejaVuSerif',
  ),
  'dejavu serif condensed' => 
  array (
    'bold' => DOMPDF_FONT_DIR . 'DejaVuSerifCondensed-Bold',
    'bold_italic' => DOMPDF_FONT_DIR . 'DejaVuSerifCondensed-BoldItalic',
    'italic' => DOMPDF_FONT_DIR . 'DejaVuSerifCondensed-Italic',
    'normal' => DOMPDF_FONT_DIR . 'DejaVuSerifCondensed',
  ),
  'glyphicons halflings' => 
  array (
    'normal' => DOMPDF_FONT_DIR . 'db1f5221e4077d6032cf1f774cf7c98a',
  ),
  'fontawesome' => 
  array (
    'normal' => DOMPDF_FONT_DIR . '3e628811faa5e7d5f1a4ab042e275cea',
  ),
  'ralewaysemibold' => 
  array (
    'normal' => DOMPDF_FONT_DIR . 'b28441fcfbc25d91adafae3654d88bbd',
  ),
  'impactedmedium' => 
  array (
    'normal' => DOMPDF_FONT_DIR . '1d916e64aa79d4190ad31e835f0e4e72',
  ),
  'grungebold' => 
  array (
    'normal' => DOMPDF_FONT_DIR . 'b50c4654fe401a6f367a54cee7057ba7',
  ),
  'bignoodletitlingregular' => 
  array (
    'normal' => DOMPDF_FONT_DIR . 'e43bea76072c0cf61deb5417ab345074',
  ),
  'all_rights_reservedregular' => 
  array (
    'normal' => DOMPDF_FONT_DIR . 'fc37bf199bc1dcd926010c2e1ececcf0',
  ),
  'punkrockshowregular' => 
  array (
    'normal' => DOMPDF_FONT_DIR . '39e60975fe12d544782ee788956b8bc4',
  ),
  'ambleregular' => 
  array (
    'normal' => DOMPDF_FONT_DIR . '197bfb1d6eea27008393b0a7b0414844',
  ),
  'open sans' => 
  array (
    'normal' => DOMPDF_FONT_DIR . 'b637264ad73f8c8b2346b3b9f4458fce',
  ),
  'roboto_condensedregular' => 
  array (
    'normal' => DOMPDF_FONT_DIR . '1059347f5a1fb2d3413761567405bf31',
  ),
  'cnnsansdisplayw04-bold' => 
  array (
    'normal' => DOMPDF_FONT_DIR . '59f9cdbe44ddf68262af252e7f1f836c',
  ),
  'cnnsansw04-regular' => 
  array (
    'normal' => DOMPDF_FONT_DIR . 'aad50b5f4b91d8535fbb3682d33f0934',
  ),
  'poppinsmedium' => 
  array (
    'normal' => DOMPDF_FONT_DIR . 'e6df485a641c933a21511ea55b6c91a3',
  ),
  'poppinssemibold' => 
  array (
    'normal' => DOMPDF_FONT_DIR . '697c4c400c156c9aeb340723d035a185',
  ),
  'venus_risingregular' => 
  array (
    'normal' => DOMPDF_FONT_DIR . 'e951d7f30c6e3a1b99fd0b7702550066',
  ),
  'ionicons' => 
  array (
    'normal' => DOMPDF_FONT_DIR . '4684ee39f18e811d345aa6e742f49bd2',
  ),
) ?>